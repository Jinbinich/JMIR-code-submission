#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 15:11:37 2023

@author: jinshi
"""

import pandas as pd
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt

# Load Excel data
df = pd.read_excel('/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/Citation analysis/Wordcloud_2000-2021_0508_sorted.xlsx', engine='openpyxl')

# Combine all words in 'Title' and 'Abstract' columns into a single string
text = ' '.join(word for word in df[['Title', 'Abstract']].astype(str).values.flatten())

# Define stop words
stopwords = set(STOPWORDS)
stopwords.update(["use","used", "compared", "one", "two", "also", "using", "new", "used", "first", "show", "result", "large", "thus", "therefore", "hence", "et", "al", "well"])  # add more words you want to exclude here

# Generate word cloud
# Increase the dimensions for higher resolution
wordcloud = WordCloud(stopwords=stopwords, width=1600, height=800, background_color='white').generate(text)

# Display the generated image
plt.figure(figsize=(20, 10))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.show()
