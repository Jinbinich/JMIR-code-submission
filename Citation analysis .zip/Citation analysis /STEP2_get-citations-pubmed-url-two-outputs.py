# loads json file from filename
# shows overall procesing time
# last saved 11-07-2023 19:00

from datetime import datetime
import json
import glob
import urllib.request
import pandas as pd

import warnings

def load_data(file):
    with open (file, "r", encoding="utf-8") as f:
        data = json.load(f) 
    #return (data[0:100]) # use only first 100 texts
    return (data)

def write_data(file, data):
    with open (file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

# returns a list of articles in PMC with PMID that cite the given article in PubMed
def get_cite_the_given(ids: list[str]):
    search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?" + \
                 "dbfrom=pubmed&linkname=pubmed_pubmed_citedin&retmode=json" + \
                 "&id="+"&id=".join(map(str, ids))
    #print("\nGet CITE THE GIVEN ...")
    #print(search_url)

    results = urllib.request.urlopen(search_url).read().decode('utf-8')
    #print("Plain result: ", results)

    results_json = json.loads(results)
    #print("JSON result: ", results_json)

    links = []
    counts = []
    i = 0
    for linksets in results_json['linksets']:
        i = i+1
        #print("Results " + str(i) + " for ", linksets['ids'][0])
        #print(linksets)
        if "linksetdbs" in linksets:
            #print(linksets['linksetdbs'][0]['links'])
            #for link in linksets['linksetdbs'][0]['links']: print(link)
            links.append(linksets['linksetdbs'][0]['links'])
            counts.append(len(linksets['linksetdbs'][0]['links']))            
        else:
            #print("NO RESULT")
            links.append([])
            counts.append(0)
    return links, counts


# returns a list of articles in PMC with PMID that a given article in PubMed cites
def get_cite_in_given(ids):
    search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi?" + \
                 "dbfrom=pubmed&linkname=pubmed_pubmed_refs&retmode=json" + \
                 "&id="+"&id=".join(map(str, ids))
    #print("\nGet CITE IN GIVEN ...")
    #print(search_url)

    results = urllib.request.urlopen(search_url).read().decode('utf-8')
    #print("Plain result: ", results)

    results_json = json.loads(results)
    #print("JSON result: ", results_json)

    links = []
    counts = []
    i = 0
    for linksets in results_json['linksets']:
        i = i+1
        #print("Results " + str(i) + " for ", linksets['ids'][0])
        #print(linksets)
        if "linksetdbs" in linksets:
            #print(linksets['linksetdbs'][0]['links'])
            #for link in linksets['linksetdbs'][0]['links']: print(link)
            links.append(linksets['linksetdbs'][0]['links'])
            counts.append(len(linksets['linksetdbs'][0]['links']))
        else:
            #print("NO RESULT")
            links.append([])
            counts.append(0)
    return links, counts

def get_citations(filename_json):
    # loading json file with two lists pmid and pubyear
    print("\n")
    print("Filename json in: ", filename_json)
    print("Loading json file ... ", end="")        
    dataLists = load_data(filename_json)
    print("done")

    # make pmid and pubyear lists
    pmid_list = dataLists[0]
    pubyear_list = dataLists[1]
    print("Number of PMID: ", len(pmid_list))
    print("Number of publication year: ", len(pubyear_list))
    
    # make empty lists for results
    cite_the_given_list = []
    ctg_count_list = []
    cite_in_given_list = []
    cig_count_list = []
    
    # run through lists
    j = 0
    fetchsize = 100
    while j < len(pmid_list):
        print("Fetching PubMed citation data", j, "to", j + fetchsize - 1, "... ", end="")
        pmid_list_fetchsize = pmid_list[j:j+fetchsize]
        ctg1, ctg2 = get_cite_the_given(pmid_list_fetchsize)
        cite_the_given_list.extend(ctg1)
        ctg_count_list.extend(ctg2)
        cig1, cig2 = get_cite_in_given(pmid_list_fetchsize)
        cite_in_given_list.extend(cig1)
        cig_count_list.extend(cig2)
        print("done")
        j = j + fetchsize 
    print("CITE THE GIVEN LIST: ", cite_the_given_list)
    print("CITE IN GIVEN LIST: ", cite_in_given_list)
    
    print("Number of CITE THE GIVEN : ", len(cite_the_given_list))
    print("Number of CTG counts : ", len(ctg_count_list))
    print("Number of CITE IN GIVEN : ", len(cite_in_given_list))
    print("Number of CIG counts : ", len(cig_count_list))    
    
    # make df for results
    print("Building dataframe ... ", end="")            
    results_df = pd.DataFrame()  
    results_df = pd.concat([results_df, pd.Series(pmid_list)], axis=1)
    results_df = pd.concat([results_df, pd.Series(pubyear_list)], axis=1)
    results_df = pd.concat([results_df, pd.Series(cite_the_given_list)], axis=1)
    results_df = pd.concat([results_df, pd.Series(ctg_count_list)], axis=1)
    results_df = pd.concat([results_df, pd.Series(cite_in_given_list)], axis=1)
    results_df = pd.concat([results_df, pd.Series(cig_count_list)], axis=1)
    results_df.columns = ['PMID', 'PubYear', 'Cite the given', 'CTG count', 'Cite in given', 'CIG count'] 
    print("done")
    
    # creating a new xlsx file with results
    print("Writing new xlsx output file ... ", end="")
    results_df.to_excel(filename_json + "-results.xlsx", index = False)
    print("done")

    # creating a new json file with results
    print("Writing new json output file ... ", end="")
    results_df.to_json(filename_json + "-results.json")
    print("done")

    
if __name__ == '__main__':

    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)

    start_time = datetime.now()
    print("Start time:", start_time)

    # Configuration
    folder = "/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/testing" # put in the name of your input and output directory

    print("Directory: ", folder)

    # Read all json files from directory and use function get_citation
    for filename in glob.glob(folder + "/*.json"):
        get_citations(filename)

    end_time = datetime.now()
    running = end_time - start_time
    print("Total calculation time: ", round(running.total_seconds()/60, 1), "minutes")
