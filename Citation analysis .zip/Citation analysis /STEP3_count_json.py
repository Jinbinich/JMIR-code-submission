import json
import heapq
import pandas as pd

# Load the data from the JSON file
filename = '/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/Citation analysis/Cited paper network /2000-2022_1707_author_counting.json-results.json'
with open(filename) as f:
    data = json.load(f)
#print("All - ", data["Cite in given"])
print("0 - ", data["Cite in given"]["0"])
print("1 - ", data["Cite in given"]["1"])


# Create a dictionary to store the counts of each number
number_counts = {}

# Iterate over each cell in the data sheet
for row in data["Cite in given"]:
    pmid_list = data["Cite in given"][row]
    print("ROW " + row + " : " + str(pmid_list))
    for pmid in pmid_list:
        #print("PMID: ", pmid)
        if pmid in number_counts:
            number_counts[pmid] += 1
        else:
            number_counts[pmid] = 1

# Find the top 10 numbers with the highest counts
top_numbers = heapq.nlargest(100, number_counts, key=number_counts.get)

# Print the top 10 numbers and their counts
print("Top 10 numbers with the highest counts:")
for number in top_numbers:
    count = number_counts[number]
    print(f"Number: {number}, Count: {count}")

# create new dataframe for results
results_df = pd.DataFrame()
results_df["PMID"] = number_counts.keys()
results_df["Count"] = number_counts.values()

# creating a new json file with results
print("Writing new xlsx output file ... ", end="")
results_df.to_csv(filename + "-counted.csv", index=False)
print("done")

