# Reading xlsx file, get pmid and pubyear, write pmid and pubyear to json file
# Last saved 11.7.2023, 18:45

import openpyxl
import json

filename_in = "/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/testing/Testing_Learning_full.xlsx"
filename_out = "/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/testing/Testing_Learning_full.json"

print("Filename xlsx in: " + filename_in)
print("Filename json out: " + filename_out)

print("Opening xlsx file ... ", end="")
wb_obj = openpyxl.load_workbook(filename_in)
sheet = wb_obj.active
print("done")

print("Number of rows: " + str(sheet.max_row))
print("Number of columns: " + str(sheet.max_column))

print("Concatenate title and abstract ... ", end="")
pmid = []
pubyear = []
i = 0
# min_col = column PMID, min_row = first row with data, max_col = column pmid
for row in sheet.iter_rows(min_col=1, min_row=2, max_col="", max_row=sheet.max_row):
    pmid.append(row[0].value)
    pubyear.append(row[1].value)
print("done")
    
print("Writing json file ... ", end="")
dataList = []
dataList.append(pmid)
dataList.append(pubyear)
jsonString = json.dumps(dataList)
jsonFile = open(filename_out, "w")
jsonFile.write(jsonString)
jsonFile.close()
print("done")