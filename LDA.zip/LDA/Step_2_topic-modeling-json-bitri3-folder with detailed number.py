# loads json file from filename
# writes lda visualization to filename-topics.html
# writes texts and topics to filename-texts.xlsx
# writes tuple topics-pmid to filename-topics.xlsx
# use configuration
# shows overall procesing time
# last saved 10-09-2022 22:00

#https://www.machinelearningplus.com/nlp/topic-modeling-gensim-python/#1introduction
import numpy as np
import json
import glob
import scipy
import pandas as pd
from datetime import datetime
import copy

#Gensim
import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel

#spacy
import spacy
from nltk.corpus import stopwords

#vis
import pyLDAvis
import pyLDAvis.gensim_models

import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

start_time = datetime.now()
print("Start time:", start_time)

# Configuration
folder = "/Users/jinshi/Desktop/Affiliation/Uni_list/Uni_list_4icu/2022_LDA" # put in the name of your input and output directory

print("Directory: ", folder)

def load_data(file):
    with open (file, "r", encoding="utf-8") as f:
        data = json.load(f) 
    #return (data[0:100]) # use only first 100 texts
    return (data)

def write_data(file, data):
    with open (file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

def lemmatization(texts, allowed_postags=["NOUN", "ADJ", "VERB", "ADV"]):
    nlp = spacy.load("en_core_web_sm", disable=["parser", "ner"])
    texts_out = []
    for text in texts:
        doc = nlp(" ".join(text))
        #doc = nlp(text)
        new_text = []
        for token in doc:
            if token.pos_ in allowed_postags:
                new_text.append(token.lemma_)
        final = " ".join(new_text)
        texts_out.append(final)
    return (texts_out)

def gen_words(texts):
    final = []
    for text in texts:
        new = gensim.utils.simple_preprocess(text, deacc=True)
        final.append(new)
    return (final)


def json2lda(filename_json):
    # JSON FILE
    # loading json file with two lists pmid and title-abstract
    print("\n")
    print("Filename json in: " + filename_json)
    print("Loading json file ... ", end="")        
    dataLists = load_data(filename_json)
    print("done")

    # get pmid and title-abstract list
    pmid = dataLists[0]
    data = dataLists[1]
    print("Size of json file: " + str(len(data)))

    #print(data[0])

    # STOPWORDS

    stop_words = stopwords.words("english")
    stop_words.extend(['also', 'well'])
    #print (stop_words)

    def remove_stopwords(texts):
        return [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]

    print("Removing stopwords ... ", end="")        
    data_nostops = remove_stopwords(data)
    print("done")

    #print(data_nostops[0])

    # LEMMATIZATION

    print("Lemmatization ... ", end="")        
    lemmatized_texts = lemmatization(data_nostops)
    #lemmatized_texts = data
    print("done")

    #print (lemmatized_texts[0])

    # PREPROCESSING

    print("Preprocessing ... ", end="")        
    data_words = gen_words(lemmatized_texts)
    print("done")

    #print("data_words[0]", data_words[0])

    # BIGRAMS AND TRIGRAMS
    # the higher the values of parameters min_count and threshold, 
    # the harder it is for words to be combined as bigrams and trigrams
    # default: min_count=5, threshold=100

    bigram_phrases = gensim.models.Phrases(data_words, min_count=4, threshold=100)
    trigram_phrases = gensim.models.Phrases(bigram_phrases[data_words], threshold=100)
    
    bigram = gensim.models.phrases.Phraser(bigram_phrases)
    trigram = gensim.models.phrases.Phraser(trigram_phrases)

    def make_bigrams(texts):
        return([bigram[doc] for doc in texts])

    def make_trigrams(texts):
        return ([trigram[bigram[doc]] for doc in texts])

    print("Processing bigrams / trigrams ... ", end="")        
    data_bigrams = make_bigrams(data_words)
    data_bigrams_trigrams = make_trigrams(data_bigrams)
    print("done")

    #print("data_bigrams_trigrams[0]:", data_bigrams_trigrams[0])

    # TF-IDF REMOVAL
    from gensim.models import TfidfModel

    id2word = corpora.Dictionary(data_bigrams_trigrams)
    #print("id2word:", id2word)

    # filter_extremes method is essential in order to ensure a desirable frequency 
    # and representation of tokens in dictionary
    # no_below : filter out tokens that appear in less than 15 documents, default 15
    # no_above : filter out tokens that appear in more than 40% of documents, default 0.4
    # keep_n : after the above two steps, keep only the first 80,000 most frequent tokens, default 80000
    print("Filter extremes ... ", end="")
    id2word_old = copy.deepcopy(id2word)
    id2word.filter_extremes(no_below=15, no_above=0.4, keep_n=80000)
    print("done")
    # check for empty list due to small documents, then dont filter extremes
    if not id2word: 
        print("Document too small, filter extremes undone")
        id2word = id2word_old
        
    #print("id2word_old:", id2word_old)
    #print("id2word:", id2word)
    texts = data_bigrams_trigrams
    #print("texts[0]", texts[0])

    print("Processing TF/IDF ... ", end="")        
    corpus = [id2word.doc2bow(text) for text in texts]

    #print(corpus[0][0:20])

    tfidf = TfidfModel(corpus, id2word=id2word)

    low_value = 0.2
    words  = []
    words_missing_in_tfidf = []
    for i in range(0, len(corpus)):
        bow = corpus[i]
        low_value_words = [] #reinitialize to be safe. You can skip this.
        tfidf_ids = [id for id, value in tfidf[bow]]
        bow_ids = [id for id, value in bow]
        low_value_words = [id for id, value in tfidf[bow] if value < low_value]
        drops = low_value_words+words_missing_in_tfidf
        for item in drops:
            words.append(id2word[item])
        words_missing_in_tfidf = [id for id in bow_ids if id not in tfidf_ids] # The words with tf-idf socre 0 will be missing

        new_bow = [b for b in bow if b[0] not in low_value_words and b[0] not in words_missing_in_tfidf]
        corpus[i] = new_bow
    print("done")
    #print(drops)

    #print(corpus[0][0:20])

    # LDA
    print("Building LDA model ... ", end="")        
    lda_model = gensim.models.ldamodel.LdaModel(corpus=corpus,
                                           id2word=id2word,
                                           num_topics=20,
                                           random_state=100,
                                           update_every=1,
                                           chunksize=100,
                                           passes=10,
                                           alpha="auto")
    print("done")

    #print(lda_model.print_topics())

    # TEXTS AND THEIR TOPICS

    def format_topics_sentences(ldamodel=None, corpus=corpus, texts=data, pmids=data):
        # Init output
        sent_topics_df = pd.DataFrame()

        # Get main topic in each document
        for i, row_list in enumerate(ldamodel[corpus]):
            row = row_list[0] if ldamodel.per_word_topics else row_list            
            # print(row)
            row = sorted(row, key=lambda x: (x[1]), reverse=True)
            # Get the Dominant topic, Perc Contribution and Keywords for each document
            for j, (topic_num, prop_topic) in enumerate(row):
                if j == 0:  # => dominant topic
                    wp = ldamodel.show_topic(topic_num)
                    topic_keywords = ", ".join([word for word, prop in wp])
                    sent_topics_df = sent_topics_df.append(pd.Series([int(topic_num), round(prop_topic,4), topic_keywords]), ignore_index=True)
                else:
                    break
        sent_topics_df.columns = ['Dominant_Topic', 'Perc_Contribution', 'Topic_Keywords']

        # Add original text to the end of the output
        contents = pd.Series(texts)
        sent_topics_df = pd.concat([sent_topics_df, contents], axis=1)
        # Add pmid to the end of the output
        contents = pd.Series(pmids)
        sent_topics_df = pd.concat([sent_topics_df, contents], axis=1)
        
        return(sent_topics_df)

    print("Appending texts and their topics ... ", end="")        

    df_topic_sents_keywords = format_topics_sentences(ldamodel=lda_model, corpus=corpus, texts=data, pmids=pmid)

    print("done")

    # Format and print
    df_dominant_topic = df_topic_sents_keywords.reset_index()
    df_dominant_topic.columns = ['Document_No', 'Dominant_Topic', 'Topic_Perc_Contrib', 'Keywords', 'Text', 'PMID']
    #print(df_dominant_topic.head(20))
    df_dominant_topic.to_excel(filename_json.replace(".json", "-texts.xlsx"))

    # MOST REPRESANTATIVE TOPIC FOR EACH TEXT

    # Display setting to show more characters in column
    pd.options.display.max_colwidth = 100

    print("Appending topics and their most prepresentative texts ... ", end="")        

    df_topics_sorted = pd.DataFrame()
    df_dominant_topic_grpd = df_topic_sents_keywords.groupby('Dominant_Topic')

    for i, grp in df_dominant_topic_grpd:
        df_topics_sorted = pd.concat([df_topics_sorted, grp.sort_values(['Perc_Contribution'], ascending=False).head(1)], 
                                     axis=0)

    print("done")

    # Format and print
    df_topics_sorted.reset_index(drop=True, inplace=True)
    df_topics_sorted.columns = ['Topic_Num', "Topic_Perc_Contrib", "Keywords", "Representative Text", "PMID"]
    #print(df_topics_sorted.head(20))
    df_topics_sorted.to_excel(filename_json.replace(".json", "-topics.xlsx"))

    #print(df_topics_sorted.sort_values("Topic_Perc_Contrib", axis = 0, ascending = False).head(20))

    # VISUALIZATION

    pyLDAvis.enable_notebook()
    vis = pyLDAvis.gensim_models.prepare(lda_model, corpus, id2word, mds="mmds", R=30)
    pyLDAvis.save_html(vis, filename_json.replace(".json", "-topics.html"))
    vis
    

# Read all xlsx files from directory and use function xlsx2json to write new json files
for filename in glob.glob(folder + "/*.json"):
    json2lda(filename)

end_time = datetime.now()
running = end_time - start_time
print("Total calculation time: ", round(running.total_seconds()/60, 1), "minutes")
