# Reading xlsx files from folder, concatenate title and abstract, write title/abstract to json file
# Ignores row if cell title or cell abstract is empty
# with separate list of PMIDs
# Last saved 23.4.2022, 11:30

import openpyxl
import json
import glob
from datetime import datetime

start_time = datetime.now()
#print("Start time:", start_time)

# Configuration
folder = "/Users/jinshi/Desktop/Affiliation/Uni_list/Uni_list_4icu/2022_LDA" # put in the name of your input an output directory

print("Directory: " + folder)

def xlsx2json(filename_in):
    print("Filename xlsx in: " + filename_in)
    filename_out = filename_in.replace(".xlsx", ".json")
    print("Filename jon out: " + filename_out)

    print("Opening xlsx file ... ", end="") 
    wb_obj = openpyxl.load_workbook(filename_in)
    sheet = wb_obj.active
    print("done")

    print("Number of rows: " + str(sheet.max_row))
    print("Number of columns: " + str(sheet.max_column))

    print("Concatenate title and abstract ... ", end="")
    pmid = []
    abstract_title = []
    i = 0
    # min_col = column PMID, min_row = first row with data, max_col = column Abstract
    for row in sheet.iter_rows(min_col=1, min_row=2, max_col=6, max_row=sheet.max_row):
        #print("0: ", row[0].value)
        #print("3: ", row[3].value)
        #print("5: ", row[5].value)
        if row[3].value and row[5].value:
            new_string = row[3].value + " " + row[5].value.replace('[','').replace(']','').replace("'",'') 
            i = i+1
            abstract_title.append(new_string)
            pmid.append(row[0].value)
    print("done")
    print("Number of not empty rows: ", i)
    
    #print(abstract_title)

    print("Writing json file ... ", end="")
    dataList = []
    dataList.append(pmid)
    dataList.append(abstract_title)
    jsonString = json.dumps(dataList)
    jsonFile = open(filename_out, "w")
    jsonFile.write(jsonString)
    jsonFile.close()
    print("done")

# Read all xlsx files from directory and use function xlsx2json to write new json files
for filename in glob.glob(folder + "/*.xlsx"):
    xlsx2json(filename)

end_time = datetime.now()
running = end_time - start_time
print("Total calculation time: ", round(running.total_seconds()/60, 1), "minutes")

