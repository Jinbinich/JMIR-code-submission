# pubmed search only on mesh in english language '"artificial intelligence"[mesh] AND English[Language]'
# counts occurence of keywords in XML entries ArticleTitle, AbstractText, KeywordList
# use configuration
# shows overall procesing time
# processes affiliation and country of first author
# problems with recognition of "woman" and "Romania" in affiliation as country "Oman"
# since 2022 Entrez ESearch will only be able to access the first 10,000 records retrieved by the search query (&retmax <= 10,000; &retstart + &retmax <= 10,000)
# searches pmid from pubmed from mindate to maxdate monthly
# description of biopython api https://biopython.org/docs/1.75/api/Bio.Entrez.html
# description of medline xml entries https://www.nlm.nih.gov/bsd/licensee/elements_descriptions.html
# pycountry provides the ISO databases for the standards https://anaconda.org/conda-forge/pycountry
# last saved 15-02-2023 15:30

import pandas as pd
import time
import random
import json
import pycountry

from Bio import Entrez
from datetime import datetime

start_time = datetime.now()
print("Start time:", start_time)

# Configuration
filename_csv = "/Users/jinshi/Desktop/Affiliation/Data extraction_1502/2023-02-15_2022_2.csv" # name of csv output file
filename_json = "/Users/jinshi/Desktop/Affiliation/Data extraction_1502/2023-02-15_2022_2.json" # name of json output file
mindate = 2022 # min pub date for pubmed search, use YYYY only
maxdate = 2022  # max pub date for pubmed search, use YYYY only
retmax = 10000  # max number of pubmed ids from each search request, 10000 max since 2022
fetchsize = 1000 # number of pubmed entries to fetch at once

# search query for PubMed
keywords = '("latent class analysis"[mesh] OR "latent class analysis"[title/abstract] OR "computer heuristics"[mesh] \
    OR "computer heuristics"[title/abstract] OR "expert systems"[mesh] OR "expert systems"[title/abstract] \
    OR "fuzzy logic"[mesh] OR "fuzzy logic"[title/abstract] OR "knowledge bases"[mesh] OR "knowledge bases"[title/abstract]\
    OR "biological ontologies"[mesh] OR "biological ontologies"[title/abstract] OR "gene ontology"[mesh] \
    OR "gene ontology"[title/abstract] OR "natural language processing"[mesh] OR "natural language processing"[title/abstract])'
  

# list of keywords to count in abstract / title
keywords_list = ["ambulatory", "artificial intelligence", "knowledge representation", "automated reasoning", "common sense reasoning", "case-based reasoning",\
    "causal inference", "causal models", "common-sense reasoning", "expert system", "fuzzy logic", "graphical models",\
    "inductive programming", "information theory", "knowledge representation & reasoning", "knowledge representation and reasoning",\
    "latent variable models", "uncertainty in artificial intelligence", "planning and scheduling", "searching", "optimisation",\
    "optimization", "bayesian optimisation", "constraint satisfaction", "evolutionary algorithm", "genetic algorithm", "gradient descent",\
    "hierarchical task network", "metaheuristic optimisation", "planning graph", "stochastic optimisation", "machine learning",\
    "active learning", "adaptive learning", "adversarial machine learning", "adversarial network", "anomaly detection",\
    "artificial neural network", "automated machine learning", "automatic classification", "automatic recognition", "bagging",\
    "bayesian modelling", "boosting", "classification", "clustering", "collaborative filtering", "content-based filtering",\
    "convolutional neural network", "data mining", "deep learning", "deep neural network", "ensemble method", "feature extraction",\
    "generative adversarial network", "generative model", "multi-task learning", "neural network", "pattern recognition",\
    "probabilistic learning", "probabilistic model", "recommender system", "recurrent neural network", "recursive neural network",\
    "reinforcement learning", "semi-supervised learning", "statistical learning", "statistical relational learning", "supervised learning",\
    "support vector machine", "transfer learning", "unstructured data", "unsupervised learning", "natural language processing",\
    "chatbot", "computational linguistics", "conversation model", "coreference resolution", "information extraction", "information retrieval",\
    "natural language understanding", "natural language generation", "machine translation", "question answering", "sentiment analysis",\
    "text classification", "text mining", "computer version", "action recognition", "face recognition", "gesture recognition",\
    "image processing", "image retrieval", "object recognition", "recognition technology", "sensor network", "visual search",\
    "audio processing", "computational auditory scene", "music analysis information retrieval", "sound description",\
    "sound event recognition", "sound source separation", "sound synthesis", "speaker identification", "speech processing",\
    "speech recognition", "speech synthesis", "multi-agent systems", "agent-based modelling", "agreement technologies",\
    "computational economics", "game theory", "intelligent agent", "negotiation algorithm", "network intelligence", "q-learning",\
    "swarm intelligence", "robotics and antomation", "cognitive system", "control theory", "human-ai interaction", "industrial robot",\
    "robot system", "service robot", "social robot", "connected and automated vehicles", "autonomous driving", "self-driving car",\
    "autonomous system", "unmanned vehicle", "autonomous vehicle", "AI services", "ai application", "intelligence software",\
    "ai benchmark", "intelligent control", "ai competition", "intelligent control system", "ai software toolkit",\
    "intelligent hardware development", "analytics platform", "intelligent software development", "big data", "intelligent user interface",\
    "business intelligence", "internet of things", "central processing unit", "machine learning framework", "computational creativity",\
    "machine learning library", "computational neuroscience", "machine learning platform", "data analytics", "personal assistant",\
    "decision analytics", "platform as a service", "decision support", "tensor processing unit", "distributed computing",\
    "virtual environment", "graphics processing unit", "virtual reality", "AI ethics", "accountability", "safety", "explainability",\
    "security", "fairness", "transparency", "privacy", "philosophy of AI", "artificial general intelligence", "weak artificial intelligence",\
    "strong artificial intelligence", "narrow artificial intelligence"]

print("\nCONFIGURATION")    
print("Filename csv: ", filename_csv)
print("Filename json: ", filename_json)
print("Min date: ", mindate)
print("Max date: ", maxdate)
print("Max number of PMIDs to retrieve: ", retmax)

def search(retmax, query, mindate, maxdate):
    Entrez.email = 'jshi1@uni-muenster.de'
    handle = Entrez.esearch(db='pubmed', 
                            retmax=retmax,
                            retmode='text', # xml
                            mindate=mindate,
                            maxdate=maxdate,  
                            datetype='pdat',
                            term=query)
    results = Entrez.read(handle)
    handle.close()
    return results

def fetch_details(start, stop, id_list):
    ids = ','.join(id_list[start:stop]) # position stop not included
    Entrez.email = 'jshi1@uni-muenster.de'
    handle = Entrez.efetch(db='pubmed',
                            retmode='xml',
                            id=ids)
    results = Entrez.read(handle)
    handle.close()
    #print(results)
    return results

def pause():
    Sleep = random.randrange(25, 80, 1)
    time.sleep(Sleep)

def get_country(stringText):
    #print("GC : ", stringText)
    #countries = sorted([country.name for country in pycountry.countries] , key=lambda x: -len(x))
    countries = pycountry.countries
    for state in pycountry.subdivisions.get(country_code='US'):
        if state.name in stringText:
            return pycountry.countries.get(alpha_2='US').name
    for country in countries:
        #print(country)
        if country.name.lower() in stringText.lower():
            return country.name
    if " Taiwan" in stringText:
        return "Taiwan"
    if " Korea" in stringText:
        return "Korea"
    if " Iran" in stringText:
        return "Iran"
    if " Russia" in stringText:
        return "Russia"    
    for country in countries:
        if country.alpha_3 in stringText:
            return country.name
    if " UK" in stringText or " U.K." in stringText:
        return "United Kingdon"
    #for country in countries:
    #    if country.alpha_2 in stringText:
    #        return country.name
    return None

def analyze_entries():
    for i, paper in enumerate(papers['PubmedArticle']):
        #print('\nPaper no.',i)
        #print('PMID: ', paper['MedlineCitation']['PMID'])
        # PUBLICATION YEAR 
        #print(paper['MedlineCitation']['Article']['Journal']['JournalIssue']['PubDate'])
        if 'Year' in paper['MedlineCitation']['Article']['Journal']['JournalIssue']['PubDate']:
            year = paper['MedlineCitation']['Article']['Journal']['JournalIssue']['PubDate']['Year']
            #print('Year: ', year)
            year_list.append("{}".format(year))
        else:
            if 'MedlineDate' in paper['MedlineCitation']['Article']['Journal']['JournalIssue']['PubDate']:
                year = paper['MedlineCitation']['Article']['Journal']['JournalIssue']['PubDate']['MedlineDate']
                #print('Year: ', year)
                year_list.append("{}".format(year))
            else:
                #print('NO YEAR')
                year_list.append("{}".format('NO YEAR'))
        # JOURNAL NAME
        journal = paper['MedlineCitation']['Article']['Journal']['Title']
        #print('Journal: ', journal)
        journal_list.append("{}".format(journal))
        #if 'MeshHeadingList' in paper['MedlineCitation']:
        #    print('MeSH: ', paper['MedlineCitation']['MeshHeadingList'])
        #print(paper['MedlineCitation'])
        
        names = []
        affiliation_checked =""
        country_checked = ""
        # check for authors in pubmed entry
        if 'AuthorList' in paper['MedlineCitation']['Article']:
            for i, authors in enumerate(paper['MedlineCitation']['Article']['AuthorList']):
                # check for affiliation and use the one from first author
                if i==0 and len(authors['AffiliationInfo']): 
                    affiliation_text = authors['AffiliationInfo'][0]['Affiliation']
                    if len(affiliation_text)>1: 
                        #print("1 : ", affiliation_text)
                        affiliation_checked = affiliation_text
                        #print("1 : ", get_country(affiliation_text))
                        country_checked = get_country(affiliation_text)
                if not 'CollectiveName' in authors:
                    if not 'ForeName' in authors:
                        #print('Author: ', authors['LastName'])
                        names.append("{}".format(authors['LastName']))
                    else:
                        #print('Author: ', authors['ForeName'], authors['LastName'])                
                        names.append("{}".format(authors['ForeName']+' '+authors['LastName']))
                else: 
                    #print('Collective Name: ', authors['CollectiveName'])                
                    names.append("{}".format(authors['CollectiveName']))
            au_list.append("{}".format(names))
        else:
            au_list.append("No authors listed")
        # print title
        #print('Title: ', paper['MedlineCitation']['Article']['ArticleTitle'])
        # print abstract
        #print('\nAbstract: ', paper['MedlineCitation']['Article']['Abstract']['AbstractText'])
        #print('\nAbstract: ', ' '.join(paper['MedlineCitation']['Article']['Abstract']['AbstractText']))
        # print keyword list
        #print('Keyword list: ', paper['MedlineCitation']['KeywordList'])
        # check number of keywords occurence in ArticleTitle, AbstractText and KeywordList
        title = format(paper['MedlineCitation']['Article']['ArticleTitle'])
        keywordlist = format(paper['MedlineCitation']['KeywordList'])
        if 'Abstract' in paper['MedlineCitation']['Article']:
            abstract = format(' '.join(paper['MedlineCitation']['Article']['Abstract']['AbstractText']))
        else: 
            abstract = "Abstract not available"
        if affiliation_checked:
            affiliation = affiliation_checked
        else:
            affiliation = "None"
        #print(affiliation)
        if country_checked:
            country = country_checked
        else:
            country = "None"
        #print(country)
        i = 0
        for keyword in keywords_list:
            count = abstract.lower().count(keyword.lower()) + title.lower().count(keyword.lower()) + keywordlist.lower().count(keyword.lower())
            #print(keyword, count)
            occurence_lists[i].append(count)
            i=i+1
        #print(occurence_lists)
        # write to lists
        pmid_list.append("{}".format(paper['MedlineCitation']['PMID']))
        title_list.append(title)
        abstract_list.append(abstract)
        affiliation_list.append("{}".format(affiliation))
        country_list.append("{}".format(country))
       

if __name__ == '__main__':

    print("\nSEARCH PUBMED")
    print("Searching PMIDs from" , mindate, "(mindate) to", maxdate, "(maxdate) by separate month ...")
    #print("Min publication date (mindate): ", mindate)
    #print(datetime.strptime(mindate, '%Y/%m/%d'))
    #print("Max publication date (maxdate): ", maxdate)
    
    # loop to search for pmids from mindate to maxdate monthy
    year = mindate
    id_list = []
    while year <= maxdate:
        month = 1
        while month <= 12:
            results = search(retmax, keywords, str(year)+'/'+str(month), str(year)+'/'+str(month))
            #print("Entrez query translation: ", results['QueryTranslation'])
            print("Number of PMIDs for", str(year)+'/'+str(month), ":", results['Count'])
            if int(results['Count']) > 9999: # per month
                print("-> More than 10000 in", str(year)+'/'+str(month))
                # 1st half
                results = search(retmax, keywords, str(year)+'/'+str(month), str(year)+'/'+str(month)+'/1')
                print("Number of PMIDs for", str(year)+'/'+str(month), "1st half:", results['Count'])
                if int(results['Count']) > 9999: # in 1st half
                    print("--> More than 10000 in 1st half", str(year)+'/'+str(month))
                    # split 1st half by flag free full text
                    results = search(retmax, keywords + " AND free full text[sb]", str(year)+'/'+str(month), str(year)+'/'+str(month)+'/1')
                    print("Number of PMIDs for", str(year)+'/'+str(month), "1st half AND free full text:", results['Count'])
                    id_list = id_list + results['IdList'] # add with flag free full text
                    results = search(retmax, keywords + " NOT free full text[sb]", str(year)+'/'+str(month), str(year)+'/'+str(month)+'/1')
                    print("Number of PMIDs for", str(year)+'/'+str(month), "1st half NOT free full text:", results['Count'])
                    id_list = id_list + results['IdList'] # add without flag free full text
                else:
                    id_list = id_list + results['IdList'] # add 1st half of month
                # 2nd half
                results = search(retmax, keywords, str(year)+'/'+str(month)+'/2', str(year)+'/'+str(month))
                print("Number of PMIDs for", str(year)+'/'+str(month), "2nd half:", results['Count'])
                if int(results['Count']) > 9999: # in 2nd half
                    print("--> More than 10000 in 2nd half", str(year)+'/'+str(month))
                    # split 2nd half by flag free full text
                    results = search(retmax, keywords, str(year)+'/'+str(month)+'/2', str(year)+'/'+str(month))
                    print("Number of PMIDs for", str(year)+'/'+str(month), "2nd half AND free full text:", results['Count'])
                    id_list = id_list + results['IdList'] # add with flag free full text
                    results = search(retmax, keywords, str(year)+'/'+str(month)+'/2', str(year)+'/'+str(month))
                    print("Number of PMIDs for", str(year)+'/'+str(month), "2nd half NOT free full text:", results['Count'])
                    id_list = id_list + results['IdList'] # add without flag free full text
                else:
                    id_list = id_list + results['IdList'] # add 2nd half of month
            else:
                id_list = id_list + results['IdList'] # add full month
            month = month+1
        year = year+1

    print("Number of all results to fetch: ", len(id_list))
    print("Last PMID in results list: ", id_list[-1])

    pmid_list = []
    title_list = []
    year_list = []
    journal_list = []
    au_list = []
    affiliation_list = []
    country_list = []
    abstract_list = []
    occurence_lists = [] # list of keyword occurence lists
    
    # initialize list with empty lists
    for keyword in keywords_list:
        occurence_lists.append([])
    
    print("\nFETCH AND ANALYZE PUBMED")
    j = 0
    while j < len(id_list):
        print("Fetching PubMed entries", j, "to", j + fetchsize - 1, "... ", end="")
        papers = fetch_details(j, j + fetchsize, id_list)
        print("done")
        print("Analyzing PubMed entries ...", end="")    
        analyze_entries()
        print("done")
        j = j + fetchsize
    
    print("\nSAVE RESULTS")
    print("Building dataframe ...", end="")            
    csv_results_df = pd.DataFrame()  
    csv_results_df = pd.concat([csv_results_df, pd.Series(pmid_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(year_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(journal_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(title_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(au_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(affiliation_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(country_list)], axis=1)
    csv_results_df = pd.concat([csv_results_df, pd.Series(abstract_list)], axis=1)
    
    i = 0
    for keyword in keywords_list:
        csv_results_df = pd.concat([csv_results_df, pd.Series(occurence_lists[i])], axis=1)
        i = i+1

    csv_results_df.columns = ['PMID', 'PubYear', 'Journal', 'Title', 'Author', 'Affiliation of first author', 'Country of first author', 'Abstract'] + keywords_list
    print("done")
    
    print(csv_results_df)
    
    print("elements in PMID list : ", len(pmid_list))
    print("elements in affiliation list : ", len(affiliation_list))
    print("elements in country list : ", len(country_list)) 
    
    print("Wrinting csv ... ", end="")
    csv_results_df.to_csv(filename_csv, index = False)    
    print("done")

    print("Concatenate title and abstract ... ", end="")
    abstract_title = []
    for i in range(len(title_list)):
        new_string = title_list[i] + " " + abstract_list[i].replace('[','').replace(']','').replace("'",'') 
        abstract_title.append(new_string)
    print("done")    
    
    print("Writing json file ... ", end="")
    dataList = []
    dataList.append(pmid_list)
    dataList.append(abstract_title)
    jsonString = json.dumps(dataList)
    jsonFile = open(filename_json, "w")
    jsonFile.write(jsonString)
    jsonFile.close()
    print("done")
        
    end_time = datetime.now()
    running = end_time - start_time
    print("\nTotal calculation time: ", round(running.total_seconds()/60, 1), "minutes")
