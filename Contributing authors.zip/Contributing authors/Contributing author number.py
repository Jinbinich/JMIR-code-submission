#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jul 16 15:09:01 2023

@author: jinshi
"""

import pandas as pd

# Read the Excel file
file_path = "/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/Citation analysis/2000-2022_1707_sorted.xlsx"
df = pd.read_excel(file_path, engine='openpyxl')

# Assuming the column with authors is named "Author"
# Split the author names on ',' and strip away leading/trailing whitespace and quotes
df["Author"] = df["Author"].str.strip('\'').str.split(',\s*')

# Flatten the list of authors and remove duplicates
all_authors = pd.unique([author for sublist in df["Author"].dropna() for author in sublist])

# NCA is the number of unique authors
NCA = len(all_authors)

print(f'Number of contributing authors (NCA): {NCA}')
