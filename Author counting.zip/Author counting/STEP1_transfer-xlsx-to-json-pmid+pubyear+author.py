# Reading xlsx file; get pmid, pubyear and authors; write pmid, pubyear and authors to json file
# Last saved 15.7.2023, 20:45

import openpyxl
import json
from datetime import datetime

start_time = datetime.now()
print("Start time:", start_time)

# set filename
filename_in = "/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/Citation analysis/Autho_sole_or_more/with PubYear/2000-2022_1707_author_counting.xlsx"
filename_out = filename_in + "-pmid-author.json"

print("Filename xlsx in: ", filename_in)
print("Filename json out: ", filename_out)

# load xlsx file
print("Opening xlsx file ... ", end="")
wb_obj = openpyxl.load_workbook(filename_in)
sheet = wb_obj.active
print("done")

print("Number of rows: ", str(sheet.max_row))
print("Number of columns: ", str(sheet.max_column))

# read pmid, pubyear and authors from xlsx data, transform authors to list 
print("Get PMID, pubyear and authors ... ", end="")
pmid = []
pubyear = []
author = []
# min_col = column PMID, min_row = first row with data, max_col = column author
for row in sheet.iter_rows(min_col=1, min_row=2, max_col=5, max_row=sheet.max_row):
    pmid.append(row[0].value) # column pmid 
    pubyear.append(row[1].value) # column pubyear
    author.append(list(row[4].value[1:-1].replace("'","").split(", "))) # string from column author to list
print("done")
print("Number of PMID rows: ", len(pmid))
print("Number of pubyear rows: ", len(pubyear))
print("Number of author rows: ", len(author))
    
# write pmid and authors to json file
print("Writing json file ... ", end="")
dataList = []
dataList.append(pmid)
dataList.append(pubyear)
dataList.append(author)
jsonString = json.dumps(dataList)
jsonFile = open(filename_out, "w")
jsonFile.write(jsonString)
jsonFile.close()
print("done")

end_time = datetime.now()
running = end_time - start_time
print("Total calculation time: ", round(running.total_seconds()/60, 1), "minutes")
