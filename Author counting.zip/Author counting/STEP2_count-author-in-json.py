# Reading json file; get pmid, pubyear and authors; count authors in list; write number to xlsx file
# Last saved 15.7.2023, 21:30

import json
import pandas as pd
from datetime import datetime

start_time = datetime.now()
print("Start time:", start_time)

# Load the data from the JSON file
filename = '/Users/jinshi/Library/Mobile Documents/com~apple~CloudDocs/PhD Paper/Revise1/Citation analysis/Autho_sole_or_more/with PubYear/2000-2022_1707_author_counting.xlsx-pmid-author.json'
with open(filename) as f:
    data = json.load(f)

# Create a list to store the number of authors
authors_count_list = []

# Iterate over each cell in the data sheet
for authors in data[2]:
    print("Authors: " + str(authors) + " | Length: " + str(len(authors)))
    authors_count_list.append(len(authors))

# create new dataframe for results
results_df = pd.DataFrame()
results_df["PMID"] = data[0]
results_df["Publication year"] = data[1]
results_df["Authors"] = data[2]
results_df["Number of authors"] = authors_count_list

# creating a new xlsx file with results
print("Writing new xlsx output file ... ", end="")
results_df.to_excel(filename + "-counted-authors.xlsx")
print("done")

end_time = datetime.now()
running = end_time - start_time
print("Total calculation time: ", round(running.total_seconds()/60, 1), "minutes")
